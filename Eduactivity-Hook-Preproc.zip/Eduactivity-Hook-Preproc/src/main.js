require("babel-runtime/regenerator");
require("webpack-hot-middleware/client?reload=true");

require("./main.css");
var index = require("./index.pug");

